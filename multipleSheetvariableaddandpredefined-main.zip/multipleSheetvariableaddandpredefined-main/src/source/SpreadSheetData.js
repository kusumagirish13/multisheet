export const SpreadSheetData = [{
    firstName: "johnson",
    lastName: "michal",
    empID: "1233",
    salary: "200000",
    age: "23",
    city: "bangalore"
},
{
    firstName: "johnson",
    lastName: "michal",
    empID: "1233",
    salary: "200000",
    age: "23",
    city: "bangalore"


},
{
    firstName: "johnson",
    lastName: "michal",
    empID: "1233",
    salary: "200000",
    age: "23",
    city: "bangalore"


},
{
    firstName: "johnson",
    lastName: "michal",
    empID: "1233",
    salary: "200000",
    age: "23",
    city: "bangalore"


},
{
    firstName: "johnson",
    lastName: "michal",
    empID: "1233",
    salary: "200000",
    age: "23",
    city: "bangalore"


}

]